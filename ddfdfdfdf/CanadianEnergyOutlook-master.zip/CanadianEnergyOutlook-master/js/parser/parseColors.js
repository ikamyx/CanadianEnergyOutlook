"use strict";

function parseColors(data) {
        // colors conversion characters
        data.forEach(g => {
            // g.variable = g.variable.replaceAll("_", ",");
            // g["label_en"] = g["label_en"].replaceAll("_", ",");
            // g["label_fr"] = g["label_fr"].replaceAll("_", ",");
        })

        return data;
}